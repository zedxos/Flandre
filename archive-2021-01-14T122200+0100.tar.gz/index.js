let FlandreScript = new Object();
FlandreScript = require('./Flandre/Flandre.js');
let Flandre = () => {
    FlandreScript();
}
Flandre();
