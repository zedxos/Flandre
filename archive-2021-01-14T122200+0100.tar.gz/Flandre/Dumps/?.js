/*This folder is used for deleted or removed commands or codes
it still may be used in future cuz i code it my ass took long then just remove it?
*/