module.exports = {
  discord_token: 'Nzk0NTgzNTgxNjU2NjEyODg1.X-87oA.46CxFUg4STNY9PI2t7nNNJ-7qkg',
  developer: '704697854207459419',
  prefix: 'f.'
}