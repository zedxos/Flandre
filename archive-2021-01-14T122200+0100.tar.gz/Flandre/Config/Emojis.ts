module.exports = {
  flandre_angery: '<:flandre_angery:793065665053327370>',
  flandre_hi: '<:flandre_hi:793065670266847272>',
  flandre_laugh: '<:flandre_laugh:793065670622445599>',
  flandre_satisfied: '<:flandre_satisfied:793065670027247626>',
  flandre_sigh: '<:flandre_sigh:793065671059308574>',
  flandre_tired: '<:flandre_tired:793065659898396700>',
  flandre_ugh: '<:flandre_ugh:793065673991389204>',
  flandre_uhh: '<:flandre_uhhh:793065670925090816>'
}